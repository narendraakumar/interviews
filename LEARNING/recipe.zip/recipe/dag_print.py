from graphviz import Digraph

dot = Digraph()
dot.node('A', 'A')
dot.node('B', 'B')
dot.node('C', 'C',shape='diamond')
dot.edge('d','d')
dot.edges(['AB', 'AB', 'AB', 'BC', 'BA', 'CB', 'CD', 'DE'])

print(dot.source)
dot.render(view=True)