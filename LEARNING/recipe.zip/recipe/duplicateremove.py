


def remstr(str_,s):
    return str_[:]

def dup(str_):
    pre = str_[0]
    next = str_[1]
    
    return str_



if __name__ == '__main__':
    print(dup("duplicccctval"))