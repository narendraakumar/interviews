from ast import main
import json
from platform import node
import pprint
from collections import defaultdict
from tkinter.messagebox import NO
from uuid import uuid4

from graphviz import Digraph

class MixInObject(object):
    def __init__(self) -> None:
        pass

    def json(self,serialize=True):
        if serialize:
            return json.dumps(self.json(),default=MixInObject.json_serializer)
        else:
            return json.loads(json.dumps(self.__dict__,default=MixInObject.json_serializer))

    @staticmethod
    def json_serializer(obj):
        if isinstance(obj, MixInObject):
            return obj.json()
        return obj.__dict__

class Node(MixInObject):

    def __init__(self,node_id=None,previous_nodes=None,next_nodes=None,json_obj=None,**kwargs) -> None:
        super().__init__()
        self.node_id = str(uuid4()) if node_id is None else node_id
        if isinstance(previous_nodes,str):
            previous_nodes = [previous_nodes]
        if isinstance(next_nodes,str):
            next_nodes = [next_nodes]

        self.previous_nodes = previous_nodes
        self.next_nodes = next_nodes
        kwargs.pop("node_id")
        self.__dict__.update(kwargs)
        if json_obj is not None:
            self.load(json_obj=json_obj)

    def load(self,json_obj):
        return self.__dict__.update(json_obj)

    def load_all_tasks(self):
        pass

class FunctionExec(Node):
    def __init__(self, node_id=None, previous_nodes=None, next_nodes=None, input_data=None, output_data=None, **kwargs) -> None:
        super().__init__(node_id, previous_nodes, next_nodes, **kwargs)
        self.input_data = input_data
        self.output_data = output_data

class ConditionExec(Node):
    def __init__(self, node_id=None, previous_nodes=None, next_nodes=None, json_obj=None,input_data=None, **kwargs) -> None:
        super().__init__(node_id, previous_nodes, next_nodes, json_obj, **kwargs)
        self.input_data = self.output_data = input_data

class AggregateExec(Node):
    def __init__(self, node_id=None, previous_nodes=None, next_nodes=None, json_obj=None, **kwargs) -> None:
        super().__init__(node_id, previous_nodes, next_nodes, json_obj, **kwargs)








class Graph(MixInObject):
    """ Graph data structure, undirected by default. """

    def __init__(self, connections, directed=False):
        self._graph = defaultdict(set)
        self._directed = directed
        self.add_connections(connections)
        self.dag = None

    def add_node()

    def add_connections(self, connections):
        """ Add connections (list of tuple pairs) to graph """

        for node1, node2 in connections:
            self.add(node1, node2)

    def add(self, node1, node2):
        """ Add connection between node1 and node2 """

        self._graph[node1].add(node2)
        if not self._directed:
            self._graph[node2].add(node1)

    def remove(self, node):
        """ Remove all references to node """

        for n, cxns in self._graph.items():
            try:
                cxns.remove(node)
            except KeyError:
                pass
        try:
            del self._graph[node]
        except KeyError:
            pass

    def is_connected(self, node1, node2):
        """ Is node1 directly connected to node2 """

        return node1 in self._graph and node2 in self._graph[node1]

    def find_path(self, node1, node2, path=[]):
        """ Find any path between node1 and node2 (may not be shortest) """

        path = path + [node1]
        if node1 == node2:
            return path
        if node1 not in self._graph:
            return None
        for node in self._graph[node1]:
            if node not in path:
                new_path = self.find_path(node, node2, path)
                if new_path:
                    return new_path
        return None

    def show_graph(self):
        edge_list = []
        dot = Digraph()
        for node in self._graph:
            for c_node in self._graph[node]:
                dot.node(node, c_node)
                edge_list.append(str(node+c_node))
        dot.edges(edge_list)
        return dot.render(view=True)
           



    def __str__(self):
        return '{}({})'.format(self.__class__.__name__, dict(self._graph))

if __name__ == '__main__':
    connections = [('A', 'B'), ('B', 'C'), ('B', 'D'),
                   ('C', 'D'), ('E', 'F'), ('F', 'C')]
    g = Graph(connections, directed=True)
    pretty_print = pprint.PrettyPrinter()
    pretty_print.pprint(g._graph)
    print(g.find_path('A','D'))
    # g.show_graph()