import tensorflow as tf
model = tf.keras.Sequential()