#!/bin/sh

for token in $@
do 
    echo $token
done